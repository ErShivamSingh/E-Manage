package com.example.hp.e_manage;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPassword extends AppCompatActivity {
ProgressBar pb;
    TextView submit;
    EditText forgotEmail;
    FirebaseAuth auth;
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        initViews();
        submit.setOnClickListener(listeners);
    }
    private void initViews(){
        submit = findViewById(R.id.forgot_button);
        forgotEmail = findViewById(R.id.forgot_emailid);
        auth = FirebaseAuth.getInstance();
        pb=findViewById(R.id.forgot);
    }

    private View.OnClickListener listeners = new View.OnClickListener() {
        Intent i;
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.forgot_button:
                    forgot();
                    break;

            }
        }
    };

    public void forgot(){
        pb.setVisibility(View.VISIBLE);
        String email = forgotEmail.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            pb.setVisibility(View.INVISIBLE);
            Toast.makeText(getApplication(), "Enter your registered email id", Toast.LENGTH_SHORT).show();
            return;
        }else{
            auth.sendPasswordResetEmail(email)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                pb.setVisibility(View.INVISIBLE);
                                Toast.makeText(getApplicationContext(),"we have sent a password reset link",Toast.LENGTH_SHORT).show();
                            } else {
                                pb.setVisibility(View.INVISIBLE);
                                Toast.makeText(getApplicationContext(), "please enter correct credential", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
        }
    }

}
