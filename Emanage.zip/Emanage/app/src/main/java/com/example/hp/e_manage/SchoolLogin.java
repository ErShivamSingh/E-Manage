package com.example.hp.e_manage;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SchoolLogin extends AppCompatActivity {

    Button sclLogin;
    TextView sclCreateAc,sclForgotPassword;
    EditText sclAffiliationId,sclAffiliationPassword;
    CheckBox sclShowHidePassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_login);
        initViews();
        sclLogin.setOnClickListener(listeners);
        sclCreateAc.setOnClickListener(listeners);
        sclShowHidePassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (!b) {
                    // show password
                    sclAffiliationPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    // hide password
                    sclAffiliationPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });
    }

    public void initViews(){
        sclLogin = findViewById(R.id.sclLoginBtn);
        sclCreateAc = findViewById(R.id.schoolCreateAccount);
        sclAffiliationId = findViewById(R.id.login_affiliation_id);
        sclAffiliationPassword = findViewById(R.id.login_affiliation_password);
        sclShowHidePassword = findViewById(R.id.school_show_hide_password);


    }

    private View.OnClickListener listeners = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i;
            switch (v.getId())
            {
                case R.id.schoolCreateAccount:
                    i = new Intent(SchoolLogin.this,SignUpSchool.class);
                    startActivity(i);
                    break;
                case R.id.sclLoginBtn:
                    login();
                    break;
            }
        }
    };

    void login(){
        FirebaseAuth auth;
        //email and password get
        String email = sclAffiliationId.getText().toString();
        String pass = sclAffiliationPassword.getText().toString();

        auth = FirebaseAuth.getInstance();
        auth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(SchoolLogin.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(!task.isSuccessful()){
                    Toast.makeText(getApplicationContext(),"login failed",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"login success",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
