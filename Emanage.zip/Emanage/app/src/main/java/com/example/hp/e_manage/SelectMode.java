package com.example.hp.e_manage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectMode extends AppCompatActivity {

    Button school,user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_mode);
        school = findViewById(R.id.loginAsSchool);
        user = findViewById(R.id.loginAsUser);
        school.setOnClickListener(listeners);
        user.setOnClickListener(listeners);
    }

    private View.OnClickListener listeners = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i;
            switch (v.getId())
            {
                case R.id.loginAsSchool:
                    i = new Intent(SelectMode.this,SchoolLogin.class);
                    startActivity(i);
                    break;
                case R.id.loginAsUser:
                    i = new Intent(SelectMode.this,MainActivity.class);
                    startActivity(i);
                    break;
            }
        }
    };
}
