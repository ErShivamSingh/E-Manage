package com.example.hp.e_manage;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    ProgressBar pb;
    private static View view;

    private static EditText emailid, password;
    private static Button loginButton;
    private static TextView forgotPassword, signUp;
    private static CheckBox show_hide_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        loginButton.setOnClickListener(listeners);
        forgotPassword.setOnClickListener(listeners);
        signUp.setOnClickListener(listeners);

    }

    public void initViews(){
        emailid = findViewById(R.id.login_emailid);
        password = findViewById(R.id.login_password);
        loginButton = findViewById(R.id.loginBtn);
        forgotPassword = findViewById(R.id.forgot_password);
        signUp = findViewById(R.id.createAccount);
        pb=(ProgressBar)findViewById(R.id.progress);
        show_hide_password = findViewById(R.id.show_hide_password);
        show_hide_password.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (!b) {
                    // show password
                    password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    // hide password
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });
    }


    private View.OnClickListener listeners = new View.OnClickListener() {
        Intent i;
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.loginBtn:
                    login();
                    break;
                case R.id.forgot_password:
                    i = new Intent(MainActivity.this,ForgotPassword.class);
                    startActivity(i);
                    break;
                case R.id.createAccount:
                    i = new Intent(MainActivity.this,SignUpUser.class);
                    startActivity(i);
                    break;
            }
        }
    };

    void login(){
        pb.setVisibility(View.VISIBLE);
        FirebaseAuth auth;
        //email and password get
        String email = emailid.getText().toString();
        String pass = password.getText().toString();

        auth = FirebaseAuth.getInstance();
        auth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(!task.isSuccessful()){
                    pb.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(),"login failed",Toast.LENGTH_SHORT).show();
                }
                else{
                    pb.setVisibility(View.INVISIBLE);
                    Toast.makeText(getApplicationContext(),"login success",Toast.LENGTH_SHORT).show();
                    Intent gotomaps=new Intent(getApplicationContext(),MapsActivity.class);
                    startActivity(gotomaps);
                    //Intent ii=new Intent(getApplicationContext(),GoogleMap.class);
                    //startActivity(ii);
                }
            }
        });

    }

    void googleLogin(){
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
    }
}
